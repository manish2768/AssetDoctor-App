import React, { useState, useEffect, useMemo } from 'react';
import { Header } from './components/Header';
import { MetricCards } from './components/MetricCards';
import { ExpiringAlertBanner } from './components/ExpiringAlertBanner';
import { AssetVaultGrid } from './components/AssetVaultGrid';
import { OCRScannerModal } from './components/OCRScannerModal';
import { AssetDetailModal } from './components/AssetDetailModal';
import { WarrantyClaimModal } from './components/WarrantyClaimModal';
import { AddAssetModal } from './components/AddAssetModal';
import { EmergencyContactModal } from './components/EmergencyContactModal';
import { WarrantyExpiryWidget } from './components/WarrantyExpiryWidget';
import { BrandSupportDirectory } from './components/BrandSupportDirectory';
import { ExportVaultModal } from './components/ExportVaultModal';
import { Asset, MetricSummary } from './types';
import { getProcessedInitialAssets } from './utils/assetUtils';
import { CheckCircle2, Camera, Sparkles } from 'lucide-react';

const STORAGE_KEY = 'assetdoctor_servivault_assets';

export default function App() {
  const [assets, setAssets] = useState<Asset[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed: Asset[] = JSON.parse(saved);
        if (parsed && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Failed to load assets from localStorage:', e);
    }
    return getProcessedInitialAssets();
  });

  const [isOCRModalOpen, setIsOCRModalOpen] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEmergencyModalOpen, setIsEmergencyModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [claimAsset, setClaimAsset] = useState<Asset | null>(null);
  const [activeStatusFilter, setActiveStatusFilter] = useState<'all' | 'active' | 'expiring_soon' | 'expired'>('all');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync state to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(assets));
    } catch (e) {
      console.error('Failed to save assets to localStorage:', e);
    }
  }, [assets]);

  // Toast Helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Compute Metrics
  const metrics: MetricSummary = useMemo(() => {
    const totalAssets = assets.length;
    const totalValuation = assets.reduce((sum, item) => sum + (item.price || 0), 0);
    const expiringSoonCount = assets.filter((item) => item.status === 'expiring_soon').length;
    const expiredCount = assets.filter((item) => item.status === 'expired').length;
    const activeCount = assets.filter((item) => item.status === 'active').length;
    const upcomingMaintenanceCount = assets.filter((item) => Boolean(item.maintenanceDueDate)).length;

    return {
      totalAssets,
      totalValuation,
      expiringSoonCount,
      expiredCount,
      activeCount,
      upcomingMaintenanceCount,
    };
  }, [assets]);

  // Assets expiring within 30 days for top banner
  const expiringAssets = useMemo(() => {
    return assets.filter((item) => item.status === 'expiring_soon');
  }, [assets]);

  // Handlers
  const handleAddAsset = (newAsset: Asset) => {
    setAssets((prev) => [newAsset, ...prev]);
    showToast(`Added "${newAsset.name}" to ServiVault!`);
  };

  const handleDeleteAsset = (id: string) => {
    const target = assets.find((a) => a.id === id);
    if (confirm(`Are you sure you want to remove ${target?.name || 'this asset'} from ServiVault?`)) {
      setAssets((prev) => prev.filter((item) => item.id !== id));
      showToast('Asset deleted from vault.');
    }
  };

  const handleUpdateAsset = (updatedAsset: Asset) => {
    setAssets((prev) => prev.map((item) => (item.id === updatedAsset.id ? updatedAsset : item)));
    setSelectedAsset(updatedAsset);
    showToast(`Updated service history for "${updatedAsset.name}"`);
  };

  const handleExportVault = () => {
    setIsExportModalOpen(true);
  };

  const handleScrollToAlerts = () => {
    setActiveStatusFilter('expiring_soon');
    const el = document.getElementById('top-notification-expiry-banner') || document.getElementById('asset-vault-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-teal-500 selection:text-slate-950">
      
      {/* Toast Feedback */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-2xl bg-slate-900 border border-teal-500/50 shadow-2xl shadow-teal-500/20 text-xs font-bold text-teal-400 animate-slide-up">
          <CheckCircle2 className="w-4 h-4 text-teal-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Fixed Header */}
      <Header
        totalValuation={metrics.totalValuation}
        totalAssetsCount={metrics.totalAssets}
        expiringSoonCount={metrics.expiringSoonCount}
        onOpenOCR={() => setIsOCRModalOpen(true)}
        onOpenAddModal={() => setIsAddModalOpen(true)}
        onOpenEmergencyModal={() => setIsEmergencyModalOpen(true)}
        onExportVault={handleExportVault}
        onScrollToAlerts={handleScrollToAlerts}
      />

      {/* Main App Container */}
      <main className="max-w-7xl mx-auto px-4 lg:px-8 py-6 space-y-6">
        
        {/* Metric Cards (Total Assets Managed with Bike/AC/RO/Car breakdown, Upcoming Maintenance & Renewal Due, Warranty Expiry Alert Section) */}
        <MetricCards
          metrics={metrics}
          assets={assets}
          onFilterStatus={(st) => setActiveStatusFilter(st)}
          activeFilter={activeStatusFilter}
          onOpenEmergencyModal={() => setIsEmergencyModalOpen(true)}
        />

        {/* Top Notification Banner for Assets Expiring Within 30 Days */}
        <ExpiringAlertBanner
          expiringAssets={expiringAssets}
          onSelectAsset={(ast) => setSelectedAsset(ast)}
          onOpenClaimModal={(ast) => setClaimAsset(ast)}
        />

        {/* Upcoming Warranty Expiries Section with 30d, 60d, 90d, Expired filter tabs */}
        <WarrantyExpiryWidget
          assets={assets}
          onSelectAsset={(ast) => setSelectedAsset(ast)}
          onOpenClaimModal={(ast) => setClaimAsset(ast)}
        />

        {/* One-Click Brand Support Directory */}
        <BrandSupportDirectory />

        {/* Main Vault Grid Section */}
        <AssetVaultGrid
          assets={assets}
          activeStatusFilter={activeStatusFilter}
          onStatusFilterChange={(st) => setActiveStatusFilter(st)}
          onSelectAsset={(ast) => setSelectedAsset(ast)}
          onClaimAsset={(ast) => setClaimAsset(ast)}
          onDeleteAsset={handleDeleteAsset}
          onOpenOCR={() => setIsOCRModalOpen(true)}
          onOpenAddModal={() => setIsAddModalOpen(true)}
        />

      </main>

      {/* Footer */}
      <footer className="mt-16 border-t border-slate-900 bg-slate-950/80 py-8 px-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-300">AssetDoctor</span>
            <span>•</span>
            <span className="text-teal-400 font-semibold">Smart Asset & Warranty Vault</span>
          </div>
          <div className="text-slate-500">
            Emergency Service Hotline & Instant OCR Invoice Scanner
          </div>
        </div>
      </footer>

      {/* Modals */}
      <OCRScannerModal
        isOpen={isOCRModalOpen}
        onClose={() => setIsOCRModalOpen(false)}
        onAddAsset={handleAddAsset}
      />

      <AddAssetModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAddAsset={handleAddAsset}
      />

      <EmergencyContactModal
        isOpen={isEmergencyModalOpen}
        onClose={() => setIsEmergencyModalOpen(false)}
      />

      <ExportVaultModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        assets={assets}
        totalValuation={metrics.totalValuation}
      />

      <AssetDetailModal
        asset={selectedAsset}
        onClose={() => setSelectedAsset(null)}
        onOpenClaimModal={(ast) => setClaimAsset(ast)}
        onUpdateAsset={handleUpdateAsset}
      />

      <WarrantyClaimModal
        asset={claimAsset}
        onClose={() => setClaimAsset(null)}
      />

      {/* Floating Action Button (FAB) for Quick Scanning */}
      <button
        onClick={() => setIsOCRModalOpen(true)}
        id="floating-scan-fab-btn"
        className="fixed bottom-6 right-6 z-40 group flex items-center gap-2.5 px-4 py-3.5 rounded-full bg-gradient-to-r from-teal-500 via-cyan-500 to-indigo-500 text-slate-950 font-black text-xs sm:text-sm shadow-2xl shadow-teal-500/40 hover:scale-105 active:scale-95 transition-all cursor-pointer border border-white/20 ring-4 ring-slate-950/60"
        title="Scan New Bill / Document with AI OCR"
      >
        <Camera className="w-5 h-5 text-slate-950 stroke-[2.5]" />
        <span className="font-extrabold tracking-tight">Scan New Bill / Document</span>
        <Sparkles className="w-4 h-4 text-slate-950 animate-pulse" />
      </button>

    </div>
  );
}
