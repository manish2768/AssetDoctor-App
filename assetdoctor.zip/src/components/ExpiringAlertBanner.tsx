import React, { useState } from 'react';
import { AlertOctagon, ArrowRight, ShieldAlert, X, ChevronRight, FileText } from 'lucide-react';
import { Asset } from '../types';
import { formatINR } from '../utils/assetUtils';

interface ExpiringAlertBannerProps {
  expiringAssets: Asset[];
  onSelectAsset: (asset: Asset) => void;
  onOpenClaimModal: (asset: Asset) => void;
}

export const ExpiringAlertBanner: React.FC<ExpiringAlertBannerProps> = ({
  expiringAssets,
  onSelectAsset,
  onOpenClaimModal,
}) => {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed || expiringAssets.length === 0) return null;

  return (
    <div
      id="top-notification-expiry-banner"
      className="relative mb-8 rounded-2xl bg-gradient-to-r from-amber-950/90 via-slate-900 to-slate-950 border-2 border-amber-500/50 p-5 shadow-2xl shadow-amber-500/10 overflow-hidden"
    >
      {/* Background Warning Mesh */}
      <div className="absolute -top-12 -right-12 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        {/* Banner Left Icon + Title */}
        <div className="flex items-start sm:items-center gap-3.5">
          <div className="p-3 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 shrink-0">
            <ShieldAlert className="w-6 h-6 animate-pulse" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold text-xs border border-amber-500/30">
                <AlertOctagon className="w-3.5 h-3.5 text-amber-400" />
                CRITICAL WARRANTY ALERT
              </span>
              <span className="text-xs text-amber-200/80 font-medium">
                {expiringAssets.length} {expiringAssets.length === 1 ? 'asset' : 'assets'} expiring within 30 days
              </span>
            </div>

            <p className="text-sm font-bold text-slate-100 mt-1">
              Action Required: Review warranty coverage before policy expiration to avoid out-of-pocket repair costs!
            </p>
          </div>
        </div>

        {/* Banner Actions */}
        <button
          onClick={() => setDismissed(true)}
          className="absolute top-3 right-3 p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 transition-colors cursor-pointer"
          aria-label="Dismiss alert"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* List of Expiring Assets */}
      <div className="mt-4 pt-4 border-t border-amber-500/20 grid grid-cols-1 md:grid-cols-2 gap-3">
        {expiringAssets.map((asset) => (
          <div
            key={asset.id}
            className="flex items-center justify-between gap-3 p-3 rounded-xl bg-slate-900/80 border border-amber-500/30 hover:border-amber-400 transition-all group"
          >
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm text-slate-100 truncate group-hover:text-amber-300 transition-colors">
                  {asset.name}
                </span>
              </div>
              <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
                <span>Value: {formatINR(asset.price)}</span>
                <span>•</span>
                <span className="font-semibold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                  {asset.daysRemaining === 0
                    ? 'Expires Today!'
                    : `Expires in ${asset.daysRemaining} days`}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => onOpenClaimModal(asset)}
                className="px-2.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-colors flex items-center gap-1 cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Claim</span>
              </button>

              <button
                onClick={() => onSelectAsset(asset)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                title="View Asset Details"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
