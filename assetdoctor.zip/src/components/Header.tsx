import React from 'react';
import { Shield, Plus, ScanText, Sparkles, Download, Bell, PhoneCall, User, CheckCircle2 } from 'lucide-react';
import { formatINR } from '../utils/assetUtils';

interface HeaderProps {
  totalValuation: number;
  totalAssetsCount: number;
  expiringSoonCount: number;
  onOpenOCR: () => void;
  onOpenAddModal: () => void;
  onOpenEmergencyModal: () => void;
  onExportVault: () => void;
  onScrollToAlerts: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  totalValuation,
  totalAssetsCount,
  expiringSoonCount,
  onOpenOCR,
  onOpenAddModal,
  onOpenEmergencyModal,
  onExportVault,
  onScrollToAlerts,
}) => {
  const currentDateFormatted = new Date().toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <header className="sticky top-0 z-30 backdrop-blur-xl bg-[#020617]/85 border-b border-slate-800/80 px-4 lg:px-8 py-3.5 transition-all">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-3.5">
        
        {/* Brand & User Welcome Profile Header */}
        <div className="flex items-center justify-between md:justify-start gap-4">
          
          {/* Logo & Brand Name */}
          <div className="flex items-center gap-3">
            <div className="relative flex items-center justify-center w-11 h-11 rounded-2xl bg-gradient-to-tr from-indigo-600 via-teal-500 to-cyan-500 p-0.5 shadow-lg shadow-teal-500/20">
              <div className="w-full h-full bg-[#020617] rounded-[14px] flex items-center justify-center">
                <Shield className="w-5 h-5 text-teal-400 animate-pulse" />
              </div>
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-teal-500"></span>
              </span>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white font-sans flex items-center gap-1.5">
                  AssetDoctor
                </h1>
                <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-400 border border-teal-500/20">
                  ServiVault V2.4
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium flex items-center gap-1.5 mt-0.5">
                <span>Smart Asset & Warranty Vault</span>
                <span className="hidden sm:inline text-slate-600">•</span>
                <span className="hidden sm:inline text-emerald-400 font-mono font-bold">
                  Valuation: {formatINR(totalValuation)}
                </span>
              </p>
            </div>
          </div>

          {/* User Welcome Profile Widget */}
          <div className="hidden lg:flex items-center gap-2.5 pl-4 border-l border-slate-800">
            <div className="relative">
              <div className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-700/80 flex items-center justify-center text-teal-400 shadow-md">
                <User className="w-5 h-5" />
              </div>
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-[#020617] rounded-full"></span>
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1">
                <span>Welcome, User</span>
                <CheckCircle2 className="w-3.5 h-3.5 text-teal-400" />
              </div>
              <div className="text-[10px] text-slate-400 font-mono">
                {currentDateFormatted} • Live Sync Active
              </div>
            </div>
          </div>

          {/* Mobile Valuation Badge */}
          <div className="sm:hidden text-right">
            <span className="text-[10px] text-slate-400 uppercase font-semibold block">Total Value</span>
            <span className="text-xs font-bold font-mono text-emerald-400">{formatINR(totalValuation)}</span>
          </div>

        </div>

        {/* Action Controls */}
        <div className="flex items-center flex-wrap gap-2">
          
          {/* Emergency Mechanic Help Quick Action */}
          <button
            onClick={onOpenEmergencyModal}
            id="header-emergency-help-btn"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 text-xs font-bold transition-all cursor-pointer shadow-md shadow-rose-500/10 active:scale-95"
            title="Emergency Service & Mechanic Contact Hotline"
          >
            <PhoneCall className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
            <span>Emergency Help</span>
          </button>

          {expiringSoonCount > 0 && (
            <button
              onClick={onScrollToAlerts}
              id="header-alert-badge-btn"
              className="relative flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold hover:bg-amber-500/20 transition-all cursor-pointer"
            >
              <Bell className="w-3.5 h-3.5 text-amber-400 animate-bounce" />
              <span>{expiringSoonCount} Alerts</span>
            </button>
          )}

          <button
            onClick={onOpenOCR}
            id="header-ocr-scan-btn"
            className="group relative flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-teal-500 via-cyan-500 to-indigo-500 text-slate-950 font-bold text-xs shadow-lg shadow-teal-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer overflow-hidden"
          >
            <ScanText className="w-4 h-4 stroke-[2.5]" />
            <span className="hidden xs:inline">Scan Document / Invoice</span>
            <span className="xs:hidden">Scan Invoice</span>
            <Sparkles className="w-3 h-3 text-slate-950" />
          </button>

          <button
            onClick={onOpenAddModal}
            id="header-add-asset-btn"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs transition-all cursor-pointer hover:border-slate-600"
          >
            <Plus className="w-4 h-4 text-emerald-400" />
            <span>Add Asset</span>
          </button>

          <button
            onClick={onExportVault}
            id="header-export-vault-btn"
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 text-xs transition-all cursor-pointer"
            title="Export Vault Backup JSON"
          >
            <Download className="w-4 h-4" />
          </button>

        </div>

      </div>
    </header>
  );
};

